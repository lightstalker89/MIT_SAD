﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;
using WebServiceCustomerOrdersRetrievalSystem.REST.Service;
using WebServiceCustomerOrdersRetrievalSystem.RESTContract;

namespace WebServiceCustomerOrdersRetrievalSystem.REST
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // opinion that there is no way to use wsdl with rest
                // http://stackoverflow.com/questions/1731434/make-a-single-wcf-service-support-both-soap-rest-and-wsdl
                // http://stackoverflow.com/questions/6030749/wsdl-for-rest-wcf
                // https://books.google.at/books?id=w02As8L5l7MC&pg=PA50&lpg=PA50&dq=wcf+wsdl+generation+rest+service&source=bl&ots=cWLoi_wS1u&sig=Lpw5gX3cfbT8UD0mMec5Fbox2T0&hl=de&sa=X&ei=otqQVOTyD4X8ULPLgcgB&sqi=2&ved=0CHEQ6AEwCQ#v=onepage&q=wcf%20wsdl%20generation%20rest%20service&f=false
                // http://stackoverflow.com/questions/4582081/how-to-create-wsdl-for-restful-ws
                // http://www.coderanch.com/t/544678/Web-Services/java/Create-WebService-REST-WSDL

                // example wsdl for rest with wsdl 2.0
                // http://www.ibm.com/developerworks/library/ws-restwsdl/

                using (WebServiceHost service = new WebServiceHost(typeof(CustomerOrdersRetrievalService),
                                                             new System.Uri("http://localhost:5556")))
                {
                    service.AddServiceEndpoint(typeof(ICustomerOrdersRetrievalService), new WebHttpBinding(), "");

                    var serviceMetadataBehavior = new ServiceMetadataBehavior();
                    serviceMetadataBehavior.HttpGetEnabled = true;
                    service.Description.Behaviors.Add(serviceMetadataBehavior);
                   
                    service.Description.Behaviors.Find<ServiceDebugBehavior>().HttpHelpPageEnabled = true;
                    service.Description.Behaviors.Find<ServiceDebugBehavior>().HttpsHelpPageEnabled = false;
                   
                    service.Open();
                    Console.WriteLine("works...");
                    Console.ReadKey();
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("troubles..." + ex.Message);
            }
            finally
            {
                Console.WriteLine("good bye...");
                Console.ReadKey();
            }

        }
    }
}

