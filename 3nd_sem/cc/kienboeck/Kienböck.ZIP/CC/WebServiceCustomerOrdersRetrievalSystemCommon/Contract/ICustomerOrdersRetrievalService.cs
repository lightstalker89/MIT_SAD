﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using WebServiceCustomerOrdersRetrievalSystem.Model;

namespace WebServiceCustomerOrdersRetrievalSystem.Contract
{
    [ServiceContract(Namespace="http://www.fhwn.ac.at/SAD_2013/Kienboeck_Daniel/")]
    public interface ICustomerOrdersRetrievalService
    {
        /// <summary>
        /// The Web Service returns a list of all customer names.
        /// </summary>
        /// <returns>Strongly typed array of customer.</returns>
        [OperationContract(Name = "getCustomers")]
        Customer[] GetCustomers();

        /// <summary>
        /// The Web Service returns a list of orders from this customer.
        /// </summary>
        /// <returns>Stongly typed array of order.</returns>
        [OperationContract(Name = "getOrders")]
        Order[] GetOrders(string name);

        /// <summary>
        /// The Web Service adds this order to the list of orders. If the customer does not exist, the order shall not be added.
        /// </summary>
        /// <param name="order">The order to add.</param>
        /// <param name="customerName">The related customer.</param>
        /// <returns>Whether the order was added or not.</returns>
        [OperationContract(Name = "addOrder")]
        bool AddOrder(Order order);

        /// <summary>
        /// The Web Service adds this customer to the list of customers.
        /// </summary>
        /// <param name="customer"></param>
        /// <returns>Whether the customer was added or not.</returns>
        [OperationContract(Name = "addCustomer")]
        bool AddCustomer(Customer customer);

        /// <summary>
        /// The Web Service deletes this order from the list of orders.
        /// </summary>
        /// <param name="order">Referenced order to delete.</param>
        /// <returns>Whether order was found and action was executed successfully.</returns>
        [OperationContract(Name = "deleteOrder")]
        bool DeleteOrder(Order order);

        /// <summary>
        /// The Web Service deletes this customer from the list of customers. All order from this customer shall be deleted as well.
        /// </summary>
        /// <param name="customer">Referenced customer to delete.</param>
        /// <returns>Whether customer was found and action was executed successfully.</returns>
        [OperationContract(Name = "deleteCustomer")]
        bool DeleteCustomer(Customer customer);
    }
}
