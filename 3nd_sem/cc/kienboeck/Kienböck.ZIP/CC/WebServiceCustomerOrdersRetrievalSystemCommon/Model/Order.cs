﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceCustomerOrdersRetrievalSystem.Model
{
    [DataContract(Namespace = "http://www.fhwn.ac.at/SAD_2013/Kienboeck_Daniel/")]
    public class Order : INotifyPropertyChanged
    {
        [DataMember]
        public string CustomerName { get; set; }
        [DataMember]
        public DateTime DateOfCreation { get; set; }
        [DataMember]
        public string[] Articles { get; set; }

        public Order()
        {
            CustomerName = string.Empty;
            Articles = new string[] { };
        }

        public string Text
        {
            get
            {
                return ToString();
            }
            set
            {
                RaiseBeforePropertyChanged();
                this.Articles = value.Split(',').Select(x => x.Trim()).ToArray();
                RaisePropertyChanged();
            }
        }



        public override string ToString()
        {
            StringBuilder text = new StringBuilder();
            bool first = true;

            foreach (var article in Articles)
            {
                if (!first)
                {
                    text.Append(", ");
                }
                text.Append(article);

                first = false;
            }

            return text.ToString();
        }

        public event PropertyChangedEventHandler BeforePropertyChanged;
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged([CallerMemberName]string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public void RaiseBeforePropertyChanged([CallerMemberName]string propertyName = "")
        {
            if (BeforePropertyChanged != null)
            {
                BeforePropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
