﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceCustomerOrdersRetrievalSystem.Model
{
    [DataContract(Namespace = "http://www.fhwn.ac.at/SAD_2013/Kienboeck_Daniel/")]
    public class Customer : INotifyPropertyChanged
    {
        private string name = string.Empty;
        [DataMember]
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                RaiseBeforePropertyChanged();
                name = value;
                RaisePropertyChanged();
            }
        }

        public override string ToString()
        {
            return Name;
        }

        public event PropertyChangedEventHandler BeforePropertyChanged;
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged([CallerMemberName]string propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        public void RaiseBeforePropertyChanged([CallerMemberName]string propertyName = "")
        {
            if (BeforePropertyChanged != null)
            {
                BeforePropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
