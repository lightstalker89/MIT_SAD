﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServiceCustomerOrdersRetrievalSystem.Model;

namespace WebServiceCustomerOrdersRetrievalSystemClient.Service
{
    public interface ICommunicationService
    {
        string InterfaceTitle { get; }
        ObservableCollection<Customer> Customers { get; set; }
        ObservableCollection<Order> Orders { get; set; }

        bool IsStartup { get; set; }
        void GetCustomers();
        void GetOrders(string name);

        void AddOrder(Order order);
        void AddCustomer(Customer customer);
        void DeleteOrder(Order order);
        void DeleteCustomer(Customer customer);

    }
}
