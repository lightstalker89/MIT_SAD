﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using WebServiceCustomerOrdersRetrievalSystem.Contract;
using WebServiceCustomerOrdersRetrievalSystem.Model;

namespace WebServiceCustomerOrdersRetrievalSystemClient.Service
{
    public class WebServiceCommunicationService : ICommunicationService
    {
        private bool isStartup = false;
        public ObservableCollection<Customer> Customers { get; set; }
        public ObservableCollection<Order> Orders { get; set; }

        public string InterfaceTitle { get { return "WebService - Interface"; } }
        public bool IsStartup
        {
            get
            {
                return isStartup;
            }
            set
            {
                isStartup = value;
            }
        }

        #region Factory

        private ChannelFactory<ICustomerOrdersRetrievalService> GetFactory()
        {
            var channelFactory = new ChannelFactory<ICustomerOrdersRetrievalService>(new WSHttpBinding(),
                                                                                            "http://localhost:5555/CustomerOrdersRetrievalSystem");
            return channelFactory;
        }

        private ICustomerOrdersRetrievalService GetInstanceOfFactory(ChannelFactory<ICustomerOrdersRetrievalService> factory)
        {
            return factory.CreateChannel();
        }

        private void CloseFactory(ChannelFactory<ICustomerOrdersRetrievalService> factory)
        {
            factory.Close();
        }

        #endregion

        public void GetCustomers()
        {
            isStartup = true;
            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).GetCustomers();

            this.Customers.Clear();
            foreach (var item in items)
            {
                this.Customers.Add(item);
            }

            this.CloseFactory(factory);

            isStartup = false;

        }

        public void GetOrders(string name)
        {
            isStartup = true;

            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).GetOrders(name);

            this.Orders.Clear();
            foreach (var item in items)
            {
                this.Orders.Add(item);
            }

            this.CloseFactory(factory);

            isStartup = false;
        }

        public void AddOrder(Order order)
        {
            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).AddOrder(order);

            this.CloseFactory(factory);
        }

        public void AddCustomer(Customer customer)
        {
            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).AddCustomer(customer);

            this.CloseFactory(factory);
        }

        public void DeleteOrder(Order order)
        {
            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).DeleteOrder(order);

            this.CloseFactory(factory);

        }

        public void DeleteCustomer(Customer customer)
        {
            var factory = this.GetFactory();
            var items = this.GetInstanceOfFactory(factory).DeleteCustomer(customer);

            this.CloseFactory(factory);
        }

    }
}
