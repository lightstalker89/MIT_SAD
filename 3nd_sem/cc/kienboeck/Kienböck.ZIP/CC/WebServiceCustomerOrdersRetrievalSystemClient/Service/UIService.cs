﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WebServiceCustomerOrdersRetrievalSystemClient.Service
{
    public class UIService : IUIService
    {
        public void Close(object obj)
        {
            var window = obj as Window;
            if(window != null)
            {
                window.Close();
            }
        }
    }
}
