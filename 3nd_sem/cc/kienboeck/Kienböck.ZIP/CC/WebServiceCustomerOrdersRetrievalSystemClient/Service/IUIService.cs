﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServiceCustomerOrdersRetrievalSystemClient.Service
{
    public interface IUIService
    {
        void Close(object window);
    }
}
