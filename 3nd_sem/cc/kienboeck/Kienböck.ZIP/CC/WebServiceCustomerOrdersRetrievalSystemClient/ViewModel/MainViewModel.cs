using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;
using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ServiceModel;
using System.Windows.Data;
using WebServiceCustomerOrdersRetrievalSystem.Contract;
using WebServiceCustomerOrdersRetrievalSystem.Model;
using WebServiceCustomerOrdersRetrievalSystemClient.Service;

namespace WebServiceCustomerOrdersRetrievalSystemClient.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        public ObservableCollection<Customer> Customers { get { return Com.Customers; } set { Com.Customers = value; } }
        public ObservableCollection<Order> Orders { get { return Com.Orders; } set { Com.Orders = value; } }

        public string WindowTitle { get; set; }
        public RelayCommand<object> CloseCommand { get; set; }
        public RelayCommand RefreshCommand { get; set; }
        public RelayCommand DeleteOrderCommand { get; set; }
        public RelayCommand DeleteCustomerCommand { get; set; }

        public ICommunicationService Com
        {
            get
            {
                return ServiceLocator.Current.GetInstance<ICommunicationService>();
            }
        }

        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            this.WindowTitle = Com.InterfaceTitle;

            Com.Customers = new ObservableCollection<Customer>();
            Com.Orders = new ObservableCollection<Order>();

            ListCollectionView customersView = (ListCollectionView)CollectionViewSource.GetDefaultView(this.Customers);

            this.CloseCommand = new RelayCommand<object>(x =>
            {
                ServiceLocator.Current.GetInstance<IUIService>().Close(x);
            });

            this.RefreshCommand = new RelayCommand(() =>
            {
                Com.GetCustomers();
                this.RaisePropertyChanged(() => this.Customers);

                customersView = (ListCollectionView)CollectionViewSource.GetDefaultView(this.Customers);
                customersView.MoveCurrentToFirst();
                Com.GetOrders(GetCurrentCustomer().Name);
                this.RaisePropertyChanged(() => this.Orders);
            });

            this.DeleteCustomerCommand = new RelayCommand(() =>
            {
                Com.DeleteCustomer(GetCurrentCustomer());
            });

            this.DeleteOrderCommand = new RelayCommand(() =>
            {
                Com.DeleteOrder(GetCurrentOrder());
            });

            customersView.CurrentChanged += (sender, e) =>
                {
                    if (Com.IsStartup)
                    {
                        return;
                    }

                    Com.GetOrders(GetCurrentCustomer().Name);
                    this.RaisePropertyChanged(() => this.Orders);
                };

            this.Orders.CollectionChanged += (sender, e) =>
            {
                if(e.Action == NotifyCollectionChangedAction.Add)
                {
                    foreach(var item in e.NewItems)
                    {
                        Order order = item as Order;
                        if (order != null)
                        {
                            order.BeforePropertyChanged += (sender2, e2) => Com.DeleteOrder(order);
                            order.PropertyChanged       += (sender2, e2) => Com.AddOrder(order);
                        }
                    }
                }

                if(Com.IsStartup)
                {
                    return;
                }
                switch (e.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                        foreach(var item in e.NewItems)
                        {
                            Order order = item as Order;
                            if(order != null)
                            {
                                order.DateOfCreation = DateTime.Now;
                                order.CustomerName = this.GetCurrentCustomer().Name;
                                Com.AddOrder(order);
                            }
                        }
                        break;
                    case NotifyCollectionChangedAction.Move:
                        break;
                    case NotifyCollectionChangedAction.Remove:
                        foreach (var item in e.OldItems)
                        {
                            Order order = item as Order;
                            if (order != null)
                            {
                                Com.DeleteOrder(order);
                            }
                        }
                        break;
                    case NotifyCollectionChangedAction.Replace:
                        foreach (var item in e.NewItems)
                        {
                            Com.AddOrder(item as Order);
                        }
                        foreach (var item in e.OldItems)
                        {
                            Com.DeleteOrder(item as Order);
                        }
                        break;
                    case NotifyCollectionChangedAction.Reset:
                        break;
                    default:
                        break;
                }
            };

            this.Customers.CollectionChanged += (sender, e) =>
            {
                if (e.Action == NotifyCollectionChangedAction.Add)
                {
                    foreach (var item in e.NewItems)
                    {
                        Customer customer = item as Customer;
                        if (customer != null)
                        {
                            customer.BeforePropertyChanged += (sender2, e2) => Com.DeleteCustomer(customer);
                            customer.PropertyChanged += (sender2, e2) => Com.AddCustomer(customer);
                        }
                    }
                }
                if (Com.IsStartup)
                {
                    return;
                }
                switch (e.Action)
                {
                    case NotifyCollectionChangedAction.Add:
                        foreach (var item in e.NewItems)
                        {
                            Com.AddCustomer(item as Customer);
                        }
                        break;
                    case NotifyCollectionChangedAction.Move:
                        break;
                    case NotifyCollectionChangedAction.Remove:
                        foreach (var item in e.OldItems)
                        {
                            Com.DeleteCustomer(item as Customer);
                        }
                        break;
                    case NotifyCollectionChangedAction.Replace:
                        foreach (var item in e.NewItems)
                        {
                            Com.AddCustomer(item as Customer);
                        }
                        foreach (var item in e.OldItems)
                        {
                            Com.DeleteCustomer(item as Customer);
                        }
                        break;
                    case NotifyCollectionChangedAction.Reset:
                        break;
                    default:
                        break;
                }
            };

            if (IsInDesignMode)
            {
                Customers.Add(new Customer() { Name = "Test1" });
                Customers.Add(new Customer() { Name = "Test2" });
                Customers.Add(new Customer() { Name = "Test3" });

                Orders.Add(new Order() { CustomerName = "Test1", Articles = new string[] { "Book", "Game" } });
                Orders.Add(new Order() { CustomerName = "Test1", Articles = new string[] { "Ball" } });

                Orders.Add(new Order() { CustomerName = "Test3", Articles = new string[] { "Newspaper" } });
            }
            else
            {
                Com.GetCustomers();
                this.RaisePropertyChanged(() => this.Customers);

                customersView = (ListCollectionView)CollectionViewSource.GetDefaultView(this.Customers);
                customersView.MoveCurrentToFirst();
                Com.GetOrders(GetCurrentCustomer().Name);
                this.RaisePropertyChanged(() => this.Orders);
            }

            
        }

        #region Customer Helpers

        private Customer GetCurrentCustomer()
        {
            ListCollectionView customersView = (ListCollectionView)CollectionViewSource.GetDefaultView(this.Customers);
            Customer customer = customersView.CurrentItem as Customer;
            return customer ?? new Customer() { Name = string.Empty };
        }

        private Order GetCurrentOrder()
        {
            ListCollectionView ordersView = (ListCollectionView)CollectionViewSource.GetDefaultView(this.Orders);
            Order order = ordersView.CurrentItem as Order;
            return order ?? new Order() { CustomerName = string.Empty, Articles = new string[] { } };
        }

        #endregion

    }
}