﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using WebServiceCustomerOrdersRetrievalSystem.Contract;
using WebServiceCustomerOrdersRetrievalSystem.Service;

namespace WebServiceCustomerOrdersRetrievalSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                using (ServiceHost service = new ServiceHost(typeof(CustomerOrdersRetrievalService),
                                                             new Uri("http://localhost:5555/CustomerOrdersRetrievalSystem")))
                {
                    service.AddServiceEndpoint(typeof(ICustomerOrdersRetrievalService), new WSHttpBinding(), "");

                    var serviceMetadataBehavior = new ServiceMetadataBehavior();
                    serviceMetadataBehavior.HttpGetEnabled = true;
                    service.Description.Behaviors.Add(serviceMetadataBehavior);
                    service.Description.Behaviors.Find<ServiceDebugBehavior>().IncludeExceptionDetailInFaults = true;

                    service.Open();

                    Console.WriteLine("works...");

                    Console.ReadKey();
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("troubles..." + ex.Message);
            }
            finally
            {
                Console.WriteLine("good bye...");
                Console.ReadKey();
            }
        }
    }
}
