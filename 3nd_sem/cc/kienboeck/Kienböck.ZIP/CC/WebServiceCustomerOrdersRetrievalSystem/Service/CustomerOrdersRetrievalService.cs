﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServiceCustomerOrdersRetrievalSystem.Contract;

namespace WebServiceCustomerOrdersRetrievalSystem.Service
{
    public class CustomerOrdersRetrievalService : ICustomerOrdersRetrievalService
    {
        private static List<Model.Customer> customers = new List<Model.Customer>();
        private static List<Model.Order> orders = new List<Model.Order>();

        static CustomerOrdersRetrievalService()
        {
            customers.Add(new Model.Customer() { Name = "Koehler" });
            customers.Add(new Model.Customer() { Name = "Safar" });
             
            orders.Add(new Model.Order() { CustomerName = "Koehler", Articles = new string[] { "Headphones", "Laptop" }, DateOfCreation=new DateTime(2010,1,1) });
            orders.Add(new Model.Order() { CustomerName = "Koehler", Articles = new string[] { "Book", "Tablet" }, DateOfCreation = new DateTime(2011, 1, 1) });

            orders.Add(new Model.Order() { CustomerName = "Safar", Articles = new string[] { "Book2" }, DateOfCreation = new DateTime(2012, 1, 1) });
            orders.Add(new Model.Order() { CustomerName = "Safar", Articles = new string[] { "Notebook", "USB cable" }, DateOfCreation = new DateTime(2013, 1, 1) });
            
        }

        public Model.Customer[] GetCustomers()
        {
            Console.WriteLine("Get Customers");
            return customers.ToArray();
        }

        public Model.Order[] GetOrders(string name)
        {
            Console.WriteLine("Get Orders");
            return orders.Where(x => x.CustomerName == name).ToArray();
        }

        public bool AddOrder(Model.Order order)
        {
            Console.WriteLine("Add Order");
            bool contains = ContainsCustomer(order.CustomerName);
            if (contains)
            {
                orders.Add(order);
            }
            return contains;
        }

        public bool AddCustomer(Model.Customer customer)
        {
            Console.WriteLine("Add Customer");
            bool contains = !ContainsCustomer(customer.Name);
            if (contains)
            {
                customers.Add(customer);
            }
            return contains;
        }

        public bool DeleteOrder(Model.Order order)
        {
            Console.WriteLine("Delete Order");
            return 0 != orders.RemoveAll(x => x.CustomerName == order.CustomerName &&
                                              x.DateOfCreation == order.DateOfCreation);
        }

        public bool DeleteCustomer(Model.Customer customer)
        {
            Console.WriteLine("Delete Customer");
            bool contains = ContainsCustomer(customer.Name);
            if(contains)
            {
                orders.RemoveAll(x => x.CustomerName == customer.Name);
                customers.RemoveAll(x => x.Name == customer.Name);
            }
            return contains;
        }

        private bool ContainsCustomer(string name)
        {
            return customers.Where(x => x.Name == name).Count() > 0;
        }
    }
}
