﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="App.xaml.cs" company="FHWN">
//   Felber, Knopf, Popovic
// </copyright>
// <summary>
//   Interaction logic for App.xaml
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace MarketPlaceClient
{
    /// <summary>
    /// Interaction logic for App
    /// </summary>
    public partial class App
    {
    }
}
