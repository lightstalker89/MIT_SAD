﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Beispiel1A_1B;

namespace UnitTest_Beispiel1A_1B
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            
        }
    }
}
